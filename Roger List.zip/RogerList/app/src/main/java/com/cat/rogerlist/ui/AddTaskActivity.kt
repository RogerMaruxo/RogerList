package com.cat.rogerlist.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class AddTaskActivity : AppCompatActivity () {

    override fun onCreate (savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ActivityAddTask
    }
}